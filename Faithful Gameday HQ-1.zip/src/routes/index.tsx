import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useRef, useState } from "react";
import confetti from "canvas-confetti";

function NoiseMeter() {
  const [level, setLevel] = useState(0);
  const [peak, setPeak] = useState(0);
  const [enabled, setEnabled] = useState(false);
  const [error, setError] = useState(false);
  const [glow, setGlow] = useState(false);

  const audioCtxRef = useRef<AudioContext | null>(null);
  const analyserRef = useRef<AnalyserNode | null>(null);
  const streamRef = useRef<MediaStream | null>(null);
  const rafRef = useRef<number | null>(null);
  const peakRef = useRef(0);
  const peakDecayRef = useRef<number | null>(null);
  const lastGlowRef = useRef(0);

  const start = async () => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true, video: false });
      streamRef.current = stream;
      const Ctx = window.AudioContext || (window as any).webkitAudioContext;
      const ctx = new Ctx();
      if (ctx.state === "suspended") await ctx.resume();
      audioCtxRef.current = ctx;
      const source = ctx.createMediaStreamSource(stream);
      const analyser = ctx.createAnalyser();
      analyser.fftSize = 256;
      analyser.smoothingTimeConstant = 0.3;
      source.connect(analyser);
      analyserRef.current = analyser;
      const data = new Uint8Array(analyser.frequencyBinCount);

      const tick = () => {
        analyser.getByteFrequencyData(data);
        let sum = 0;
        for (let i = 0; i < data.length; i++) sum += data[i];
        const avg = sum / data.length;
        const v = Math.min(100, (avg / 255) * 100 * 1.8);
        setLevel(v);
        if (v > peakRef.current) {
          peakRef.current = v;
          setPeak(v);
        }
        const now = performance.now();
        if (v >= 80 && now - lastGlowRef.current > 2000) {
          lastGlowRef.current = now;
          setGlow(true);
          setTimeout(() => setGlow(false), 200);
        }
        rafRef.current = requestAnimationFrame(tick);
      };
      tick();

      peakDecayRef.current = window.setInterval(() => {
        if (peakRef.current > 0) {
          peakRef.current = Math.max(0, peakRef.current - 1);
          setPeak(peakRef.current);
        }
      }, 50);

      setEnabled(true);
      setError(false);
    } catch {
      setError(true);
      setEnabled(false);
    }
  };

  useEffect(() => {
    start();
    return () => {
      if (rafRef.current) cancelAnimationFrame(rafRef.current);
      if (peakDecayRef.current) clearInterval(peakDecayRef.current);
      if (streamRef.current) streamRef.current.getTracks().forEach((t) => t.stop());
      if (audioCtxRef.current) audioCtxRef.current.close();
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const tier =
    level <= 20 ? "🤫 Too Quiet"
    : level <= 40 ? "👏 Warming Up"
    : level <= 60 ? "📣 Getting Loud"
    : level <= 80 ? "🔥 LET'S GO!"
    : "🎉 STADIUM MODE!";

  const labelStyle = { textShadow: "2px 2px 6px rgba(0,0,0,0.9)" } as const;

  return (
    <div className="absolute bottom-[3%] left-[25%] right-[5%]">
      <div className="text-3xl font-extrabold text-white tracking-wide text-center mb-2" style={labelStyle}>
        MAKE SOME NOISE!
      </div>
      {!enabled ? (
        <button
          onClick={start}
          className="sb-btn mx-auto block bg-black/60 border-4 border-[#B3995D] px-6 py-3 text-white font-bold shadow-lg"
        >
          🎤 Tap to enable the mic and make some noise!
          {error && <span className="ml-2 opacity-80">(permission needed)</span>}
        </button>
      ) : (
        <div
          className="relative h-12 bg-black/60 border-4 border-[#B3995D] overflow-hidden shadow-lg transition-transform duration-200"
          style={{
            transform: glow ? "scale(1.05)" : "scale(1)",
            boxShadow: glow ? "0 0 30px 8px rgba(179, 153, 93, 0.8)" : undefined,
          }}
        >
          <div
            className="h-full transition-all duration-100 ease-out"
            style={{
              width: `${level}%`,
              background: "linear-gradient(to right, #AA0000 0%, #C9302C 50%, #B3995D 100%)",
            }}
          />
          {peak > 0 && (
            <div
              className="absolute top-0 w-1 h-full bg-[#FFD700]"
              style={{ left: `calc(${peak}% - 2px)` }}
            />
          )}
          <div
            className="absolute inset-0 flex items-center justify-center text-2xl font-bold text-white pointer-events-none"
            style={labelStyle}
          >
            <span>{Math.round(level)}%</span>
          </div>
        </div>
      )}
    </div>
  );
}

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [{ title: "49ers Gameday" }],
  }),
  component: Soundboard,
});

const SOUNDS = [
  { label: "HYPESONG", src: "/assets/Song_2_Blur.mp3" },
  { label: "FOGHORN", src: "/assets/Foghorn_Download.mp3" },
  { label: "DEFENSE", src: "/assets/Defense.mp3" },
];

const FOX = { label: "FOX", src: "/assets/nfl-on-fox.mp3" };

const GAMEDAY = { label: "GAMEDAY", src: "/assets/Gameday.mp3" };

function Soundboard() {
  const audioRefs = useRef<(HTMLAudioElement | null)[]>([]);
  const foghornButtonRef = useRef<HTMLButtonElement>(null);
  const cameraInputRef = useRef<HTMLInputElement>(null);

  const handleCameraCapture = () => {
    cameraInputRef.current?.click();
  };


  const fireFoghornConfetti = (buttonElement: HTMLElement | null) => {
    if (!buttonElement) return;
    const rect = buttonElement.getBoundingClientRect();
    const originX = (rect.left + rect.width / 2) / window.innerWidth;
    const originY = (rect.top + rect.height / 2) / window.innerHeight;
    confetti({
      particleCount: 180,
      spread: 100,
      startVelocity: 60,
      gravity: 0.9,
      ticks: 300,
      origin: { x: originX, y: originY },
      colors: ["#AA0000", "#C9302C", "#8B0000", "#B3995D", "#C9A84C", "#FFD700"],
      scalar: 1.8,
      shapes: ["square", "circle"],
      zIndex: 9999,
    });
  };

  const handlePlay = (i: number) => {
    const a = audioRefs.current[i];
    if (!a) return;
    try {
      a.pause();
      a.currentTime = 0;
    } catch {}
    a.play().catch(() => {});
  };

  return (
    <>
      <style>{`
        html, body { margin: 0; padding: 0; overflow: hidden; height: 100%; width: 100%; }
        body { -webkit-tap-highlight-color: transparent; }
        .sb-btn { touch-action: manipulation; -webkit-tap-highlight-color: transparent; user-select: none; -webkit-user-select: none; }
        .sb-label { text-shadow: 2px 2px 4px rgba(0,0,0,0.8); user-select: none; -webkit-user-select: none; }
        .sb-img { filter: drop-shadow(0 4px 6px rgba(0,0,0,0.5)); pointer-events: none; }
        .sb-rotate { display: none; }
        @media (orientation: portrait) {
          .sb-board { display: none !important; }
          .sb-rotate { display: flex; }
        }
      `}</style>

      <div
        className="sb-board h-screen w-screen overflow-hidden relative"
        style={{
          backgroundImage: "url(/assets/background.png)",
          backgroundSize: "cover",
          backgroundPosition: "center",
          backgroundRepeat: "no-repeat",
        }}
      >
        <NoiseMeter />
        <button
          aria-label={GAMEDAY.label}
          onClick={() => handlePlay(4)}
          className="sb-btn absolute top-[3%] left-[3%] bg-transparent border-0 p-0 cursor-pointer flex flex-col items-center gap-2 transition-transform duration-100 active:scale-[0.92]"
        >
          <span
            style={{
              fontSize: "1.6875rem",
              fontWeight: 700,
              color: "#AA0000",
              WebkitTextStroke: "1px #ffffff",
              textShadow:
                "-1px -1px 0 #fff, 1px -1px 0 #fff, -1px 1px 0 #fff, 1px 1px 0 #fff",
              userSelect: "none",
            }}
          >
            GAMEDAY SONG
          </span>
          <img
            src="/assets/button.png"
            alt=""
            className="sb-img w-[14.49vw] h-[14.49vw] max-w-[186px] max-h-[186px] min-w-[124px] min-h-[124px] object-contain"
            draggable={false}
          />
          <audio
            ref={(el) => {
              audioRefs.current[4] = el;
            }}
            src={GAMEDAY.src}
            preload="auto"
          />
        </button>

        <div className="absolute bottom-[16%] left-0 right-[28%] flex flex-row justify-evenly items-end px-[5%]">
          {SOUNDS.map((s, i) => (
            <button
              key={s.label}
              ref={i === 1 ? foghornButtonRef : undefined}
              aria-label={s.label}
              onClick={(e) => {
                handlePlay(i);
                if (i === 1) fireFoghornConfetti(e.currentTarget);
              }}
              className="sb-btn bg-transparent border-0 p-0 cursor-pointer flex flex-col items-center gap-2 transition-transform duration-100 active:scale-[0.92]"
            >
              <img
                src="/assets/button.png"
                alt=""
                className="sb-img w-[16.1vw] h-[16.1vw] max-w-[207px] max-h-[207px] min-w-[138px] min-h-[138px] object-contain"
                draggable={false}
              />
              <span className="sb-label font-bold text-white" style={{ fontSize: "2.25rem" }}>
                {s.label}
              </span>
              <audio
                ref={(el) => {
                  audioRefs.current[i] = el;
                }}
                src={s.src}
                preload="auto"
              />
            </button>
          ))}
        </div>

        <button
          aria-label={FOX.label}
          onClick={() => handlePlay(3)}
          className="sb-btn absolute bottom-[16%] right-[4%] bg-transparent border-0 p-0 cursor-pointer flex flex-col items-center gap-2 transition-transform duration-100 active:scale-[0.92]"
        >
          <img
            src="/assets/button.png"
            alt=""
            className="sb-img w-[16.1vw] h-[16.1vw] max-w-[207px] max-h-[207px] min-w-[138px] min-h-[138px] object-contain"
            draggable={false}
          />
          <span className="sb-label font-bold text-white" style={{ fontSize: "2.25rem" }}>
            {FOX.label}
          </span>
          <audio
            ref={(el) => {
              audioRefs.current[3] = el;
            }}
            src={FOX.src}
            preload="auto"
          />
        </button>

        <button
          aria-label="Take a selfie"
          onClick={handleCameraCapture}
          className="sb-btn absolute top-[3%] left-[22%] bg-transparent border-0 p-0 cursor-pointer flex flex-col items-center gap-2 transition-transform duration-100 active:scale-[0.92]"
        >
          <span
            style={{
              fontSize: "1.6875rem",
              fontWeight: 700,
              color: "#AA0000",
              WebkitTextStroke: "1px #ffffff",
              textShadow:
                "-1px -1px 0 #fff, 1px -1px 0 #fff, -1px 1px 0 #fff, 1px 1px 0 #fff",
              userSelect: "none",
            }}
          >
            GAMEDAY SELFIE
          </span>
          <img
            src="/assets/camera.png"
            alt=""
            className="sb-img w-[14.49vw] h-[14.49vw] max-w-[186px] max-h-[186px] min-w-[124px] min-h-[124px] object-contain"
            draggable={false}
          />
        </button>

        <input
          ref={cameraInputRef}
          type="file"
          accept="image/*"
          capture="user"
          style={{ display: "none" }}
        />
      </div>


      <div className="sb-rotate fixed inset-0 bg-black text-white items-center justify-center text-center p-8 z-50">
        <div>
          <div className="text-6xl mb-4">↻</div>
          <div className="text-2xl font-bold">Please rotate your device</div>
          <div className="text-base opacity-80 mt-2">
            This soundboard is designed for landscape mode
          </div>
        </div>
      </div>
    </>
  );
}
